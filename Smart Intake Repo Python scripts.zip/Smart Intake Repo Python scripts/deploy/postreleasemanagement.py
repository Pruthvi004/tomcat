import sys
import os
import subprocess
import pysftp


#Release Notes creation
en=sys.argv[1]
#en=${bamboo.ENV}
build=sys.argv[2]
#build=${bamboo.buildNumber}
pr=sys.argv[3]

bwd=os.getcwd

#zero out FeatureIDlist.xml XML on bamboo server
cmd='echo >/apps/DevOps/Request/FeatureIDList.xml'
os.system(cmd)

#Remove FeatureIDList.xml from dev server
#ssh srcwpd@va33.wellpoint.com rm -rf /apps/pegasharedfloder/other_apps/DevOps/Requestr/FeatureIDlist.xml
#sftp srewpgadmin@va33.wellpoint.com <<EOF
# make sure you install pysftp module
with pysftp.Connection('srcwpgadm@va33.wellpoint.com') as sftp:

    with sftp.cd('/apps/pegashared/other_apps/DEvOps/Request/'):           
        sftp.remove('FeatureIDlist.xml')  