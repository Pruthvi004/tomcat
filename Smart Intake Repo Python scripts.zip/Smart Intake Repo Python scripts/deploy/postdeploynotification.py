import sys
import os
import subprocess
import smtplib, ssl

env=sys.argv[1]
buildNumber=sys.argv[2]
planName=sys.argv[3]
BBWD=sys.argv[4]

reportpath_name= BBWD+'/PostDeploymentReport/Build_$'+buildNumber+'/CompareResult*.xlsx'
print ("Report & its Path: $reportpath_name")

cmd="dirname ",reportpath_name
report_path=subprocess.check_output('cmd', shell=True)

cmd="basename ",reportpath_name
report_name=subprocess.check_output('cmd', shell=True)


print ("Report name is :"+report_name)

Deployment_Info_txt =BBWD+"/Deployment_Info.txt"

cmd='cat '+Deployment_Info_txt
bodymessage=subprocess.check_output('cmd', shell=True)
print ("Message to be sent is $bodymessage")

port = 465  # For SSL
smtp_server="<please fill this>"
sender_email="<please fill this>"
receiver_email="<please fill this>"
password=input("Type your password and press enter:")


ATTACH="$BBWD/report_HandleVersion.txt"

message="""
Subject: <please put the subject>

Team
Build Plan: {planName}
Build Number: {buildNumber}

"""+bodymessage+"""

Thank you for using Eagle Eye Devops

Eagle Eye Devops Team"""
 
context = ssl.create_default_context()
with smtplib.SMTP(smtp_server, port) as server:
    server.starttls(context=context)
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)