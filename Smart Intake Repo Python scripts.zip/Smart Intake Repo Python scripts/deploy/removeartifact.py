#REmoves the jar file after it has been sent to artifactory
import os
import sys
import subprocess

buildNumber=sys.argv[1]
BBWD=sys.argv[2]

agentDevOpsFloderPath='/apps/DevOps'
agentDevOpsFloderPath='/apps/DevOps'

os.remove(agentDevOpsFloderPath+'/Products/Build_'+buildNumber)
os.remove(BBWD+"/Products/Build_"+buildNumber)
