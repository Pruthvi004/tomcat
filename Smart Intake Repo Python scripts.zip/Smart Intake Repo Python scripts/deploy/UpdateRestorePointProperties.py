import os
import sys
import subprocess

env=sys.argv[1]
RestorePoint=sys.argv[2]
BBWD=sys.argv[3]
bwd=os.getcwd()

utilsfloder=BBWD+'/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/'
agentDevOpsFloderPath='/apps/DevOps'
devDevOpsFloderPath='/apps/DevOps'

print ("Enviornment for Rollback is "+env)
print ("Restore Point Name is "+RestorePoint)



if(not RestorePoint):
     print ("There is no Restore Point Name. Exiting Now.")
     exit 

if(not env):
     print("There is no Environment for Restore Point.Exiting Now.")
     exit 

print("Before Upating the "+env+"_prpcServiceutils.properties")

cmd="sed -i -e '/rollback.restorePointName=/ s|=.*|='"+RestorePoint+"'|'"+utilsfloder+"/"+env+"_prpcServiceutils.properties"
os.system(cmd)

cmd='grep ^rollback.restorePointName '+utilsfloder+'/'+env+'_prpcServiceutils.properties|cut -d =-f2'
ResorePoint_Path=subprocess.check_output('cmd', shell=True)

print("Rollback Restore Point Path is : "+ResorePoint_Path)


if(not ResorePoint_Path):
   print ("Could not get the Restore Point Path.Exiting Now.")
   exit 

#set the managementstorePoint name

cmd="sed -i -e '/manageRestorePoint.restorePointName=/ s|=.*|='"+RestorePoint+"'|'"+utilsfloder+"/"+env+"_prpcServiceutils.properties"
os.system(cmd)

cmd='grep ^manageRestorePoint.restorePointName '+utilsfloder+'/'+env+'_prpcServiceutils.properties |cut -d= -f2'
updatedrestorepoint_name=subprocess.check_output('cmd', shell=True)

print ("Updated Restore Point name is: "+updatedrestorepoint_name)

#set the manageRestorePoint action "get"

restore_action='get'
cmd="sed -i -e '/manageRestorePoint.action=/ s|=.*|='$restore_action'|' "+utilsfloder+"/"+env+"_prpcServiceutils.properties"
os.system(cmd)


cmd='grep ^manageRestorePoint.action '+utilsfloder+'/'+env+'_prpcServiceutils.properties| cut -d= -f2'
updatedrestorepoint_action =subprocess.check_output('cmd', shell=True)

print ('Updated Restore action is :'+updatedrestorepoint_action)
 

 