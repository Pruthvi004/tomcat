import sys
import os
import subprocess
import pysftp


#Release Notes Creation
en=sys.argv[1]
#en=${bamboo.ENV}
build=sys.argv[2]
#build=${bamboo.buildNumber}
app=sys.argv[3]
bwd=os.getcwd

agentDevOpsFloderPath='/apps/DevOps'
devDevOpsFloderPath='/apps/DevOps'

featureFile="$agentDevOpsFloderPath/Request/${app}FeatureIDList.xml"
featureFile_SIT="$agentDevOpsFloderPath/Request/${app}FeatureIDList_SIT.xml"
featureFile_PERF="$agentDevOpsFloderPath/Request/${app}FeatureIDList_PERF.xml"
featureFile_CI="$agentDevOpsFloderPath/Request/${app}FeatureIDList_CI.xml"
featureFile_UAT="$agentDevOpsFloderPath/Request/${app}FeatureIDList_UAT.xml"

# make sure you install pysftp module
with pysftp.Connection('srcwpd@va33.wellpoint.com') as sftp:

    with sftp.cd(agentDevOpsFloderPath+'/Request'):
        sftp.chmod(devDevOpsFloderPath+'/Request/${app}FeatureIDlist.xml' ,755)       
        sftp.cd(devDevOpsFloderPath+'/Request')  
        sftp.get('${app}FeatureIDlist.xml')         


cmd='cat '+featureFile
update= subprocess.check_output('cmd', shell=True)

print(update) 

cmd='echo $update >> '+featureFile_CI+'; echo $update >> '+featureFile_SIT+'; echo $update >> '+featureFile_PERF+'; echo $update >> '+featureFile_UAT
os.system(cmd)



