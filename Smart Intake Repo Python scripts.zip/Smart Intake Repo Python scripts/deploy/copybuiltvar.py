import os
import sys
import shutil

buildKey=sys.argv[1]
app=sys.argv[2]
bwd=os.getcwd

agentDevopsFloderPath='/apps/DevOps'
devDevOpsFloderPath='/apps/DevOps'

print ("Copying Build Info to the Directory")
shutil.copy2(agentDevopsFloderPath+"/ArtifactoryInfo/"+app+"KMBuild.info" , bwd+"/")
shutil.copy2(agentDevopsFloderPath+"/ArtifactoryInfo/"+app+"KMBuild.info" , bwd+"/KMBuild.info")