import sys
import os
import subprocess
import pysftp

#Release Notes Creation
en=sys.argv[1]
#en=$(bamboo.buildNumber)
build=sys.argv[2]
#build=${bamboo.buildNumber}
bwd=os.getcwd

agentDevOpsFloderpath='/apps/agentDevOpsFloder'
devDevOpsFloderPath='/apps/Devops'

#Zero Out FeatureIDList.xml XML on bamboo server
cmd='echo >'+agentDevOpsFloderpath+'/Request/${app}FeatureIDList.xml'
os.system(cmd)

#Remove FeatureIDList.xml XML from dev server
#ssh srcwpd@va33.wellpoint.com rm -rf /apps/pegasharedfloder/other_apps/DevOps/Requestr/FeatureIDlist.xml
#sftp srewpgadmin@va33.wellpoint.com <<EOF
# make sure you install pysftp module
with pysftp.Connection('srcwpgadm@va33.wellpoint.com') as sftp:

    with sftp.cd(devDevOpsFloderPath+"/Request/"):           
        sftp.remove('${app}FeatureIDlist.xml')   
