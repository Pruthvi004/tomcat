import sys
import os
import subprocess
import pysftp


#en=${bamboo.ENV}
build=sys.argv[2]
#build=${bamboo.buildNumber}
pr=sys.argv[3]
bwd=os.getcwd

rmfile=bwd+"/build/Request/RMRequestData_$en.xml"
rmfile_SIT=bwd+"/build/Request/RMRequestData_SIT.xml"
rmfile_PERF=bwd+"/build/Request/RMRequestData_PERF.xml"
rmfile_CI=bwd+"/build/Request/RMRequestData_CI.xml"
rmfile_CRT=bwd+"/build/Request/RMRequestData_CRT.xml"

# make sure you install pysftp module
with pysftp.Connection('srcwpd@va33.wellpoint.com ') as sftp:

    with sftp.cd('/apps/pegashared/other_apps/Devops/Request'):
        sftp.chmod('/app/pegashares/other_apps/DevOps/Request/FeatureIDList.xml' ,755)       
        sftp.cd('/apps/pegashared/other_apps/DevOps/Request')  
        sftp.get('FeatureIDlist.xml')         

cmd='cat /apps/pegashared/other_apps/DEvOps/Request/FeatureIDList.xml'
update= subprocess.check_output('cmd', shell=True)

print (update)
cmd='sed -i "/<RMTableInput>/a '+update+'"'+rmfile
os.system(cmd)
print(rmfile)
cmd='sed -i "/<RMTableInput>/a '+update+'"'+rmfile_SIT
os.system(cmd)
cmd='sed -i "/<RMTableInput>/a '+update+'"'+rmfile_PERF
os.system(cmd)
cmd='sed -i "/<RMTableInput>/a '+update+'"'+rmfile_CI
os.system(cmd)
cmd='sed -i "/<RMTableInput>/a '+update+'"'+rmfile_CRT
os.system(cmd)