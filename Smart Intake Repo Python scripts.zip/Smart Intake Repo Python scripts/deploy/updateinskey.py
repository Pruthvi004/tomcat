import os
import sys
import subprocess
ENV=sys.argv[1]
INSKEY=sys.argv[2]
BBWD=sys.argv[3]
PostDeployRequestData_xml=BBWD+'/Request/PostDeployRequestData.xml'


if(not INSKEY):    
   print ("Updating Product INSKEY into $PostDeployRequestData_xml")
   cmd='sed -i -e "s|<ProductInsKey>.*</ProductInsKey>|<ProductInsKey>'+INSKEY+'</ProductInsKey>|g" '+PostDeployRequestData_xml
   os.system(cmd)

   cmd='cat '+PostDeployRequestData_xml+'|grep ProductInsKey |cut -d ">" -f2|cut -d "<" -f1|xargs)'
   updatedinskey=subprocess.check_output('cmd', shell=True)

if INSKEY != updatedinskey :
   print ("Product INSKEY updated to "+PostDeployRequestData_xml+" file failed.")
   exit


if(not ENV):
   print("Updating ENV into "+PostDeployRequestData_xml)
   cmd='sed -i -e "s|<TargetEnvName>.*</TargetEnvName>|<TargetEnvName>'+ENV+'</TargetEnvName>|g" '+PostDeployRequestData_xml
   os.system(cmd)

   cmd='cat '+PostDeployRequestData_xml+'| grep TargetEnvName|cut -d">" -f2|cut -d "<" -f1|xargs'
   updatedenv=subprocess.check_output('cmd', shell=True)



if ENV != updatedenv : 
    print ("ENV update to "+PostDeployRequestData_xml+" file failed.")
    exit 

cmd='cat '+PostDeployRequestData_xml
os.system(cmd)