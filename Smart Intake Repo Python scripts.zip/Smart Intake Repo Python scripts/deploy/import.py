import os
import sys

ENV=sys.argv[1]
BBWD=sys.argv[2]
utilsfloder=BBWD+'/prpcServiceUtils_84/prpcServiceUtils/scripts/utils'

os.chdir(utilsfloder)
cmd=utilsfloder+'/'+ENV+'_prpcServiceUtils.sh import'
os.system(cmd)