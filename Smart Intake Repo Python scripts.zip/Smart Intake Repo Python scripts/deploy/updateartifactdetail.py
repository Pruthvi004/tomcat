import os
import sys
import subprocess
env=sys.argv[1]
buildNumber=sys.argv[2]
BBWD=sys.argv[3]

utilsfloder=BBWD+'/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/'
agentDevOpsFloderPath='/apps/DevOps'
devDevOpsFloderPath='/apps/DevOps'

os.mkdir('/apps/DevOps/temp')
subprocess.call(['chmod', '-R', '+x', '/apps/DevOps/temp'])
subprocess.call(['chmod', '-R', '+x', '/apps/DevOps/temp/*'])


print("copying the files to local floder")

product_path_new=BBWD+'/Products/Build_'+buildNumber

cmd="ls -ltr "+product_path_new+"/*.zip|tail -1|awk '{print $9}'"
product_name=subprocess.check_output('cmd', shell=True)

print (product_path_new)
print (product_name)

cmd="basename ",product_name
product_path_new=subprocess.check_output('cmd', shell=True)




if(not product_path_new):
    print("Could not get the product name .Exiting now.")
    exit 
productpath_name_new=product_path_new+"/"+product_name

cmd="sed -i -e '/import.archive.path=/s|=.*|='"+productpath_name_new+" '|' "+utilsfloder+"/"+env+"_prpcServiceUtils.properties"
os.system(cmd)

cmd='grep ^import.archive.path '+utilsfloder+'/'+env+'_prpcServiceUtils.properties | cut -d' ' -f2'
archive_path=subprocess.check_output('cmd', shell=True)

print ("Archive path: "+archive_path)

if(not archive_path):
   print ("Could not get the archive path.Exiting now.")
   exit
