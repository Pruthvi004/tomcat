import os
import sys
import subprocess
import pysftp

#Post Deployment Check
ENV=sys.argv[1]
buildNumber=sys.argv[2]
INSKEY=sys.argv[3]
BBWD=sys.argv[4]
bwd=os.getcwd

agentDevOpsFloderPath='/apps/DevOps'
devDEvOpsFloderPath='/apps/DevOps'

postDeployRequestData_xml="$BBWD/Request/PostDeployRequestData.xml"
postDeployNotification_sh="$BBWD/deploy/postDeployNotification.sh"




if(not INSKEY):
   print ("Updating Product INSKEY into $postDeployRequestData_xml")
   cmd='sed -i -e "s|<ProductInsKey>.*</ProductInsKey>|<ProductInsKey>'+INSKEY+'</ProductInsKey>|g" '+postDeployRequestData_xml
   os.system(cmd)
   cmd='cat '+postDeployRequestData_xml+'|grep ProductInsKey |cut =d ">" -f2 |cut -d "<" -f1|xargs'  
   updatedinskey= subprocess.check_output('cmd', shell=True)


if INSKEY != "Sucess" : 
    print ("PostDeployment API call failed.") 
    exit

cmd= 'cat '+postDeployRequestData_xml
os.system(cmd)

cmd='curl --header "Content_type: text/xml;charset=UTF-8" --cacert /apps/tomcat7/tomcat-client.jks --insecure --data @$'+postDeployRequestData_xml+' va33.wellpoint.com >report_rulecountcompare.txt'
os.system(cmd)

cmd= 'cat report_rulecountcompare.txt'
os.system(cmd)

cmd='cat report_rulecountcompare.txt |grep PostDeployStatus|cut -d: -f1|cut -d ">" -f2|xargs'
result=subprocess.check_output('cmd', shell=True)

cmd='cat report_rulecountcompare.txt |grep PostDeployStatus |cut -d- -f2 |cut -d\< -f1'
reportpath_name=subprocess.check_output('cmd', shell=True)

print ("Results from PostDeployment api call is "+result)

if result != "Sucess": 
    print ("PostDeployment API call failed.")
    exit 

print ("Report & its path: "+reportpath_name)

cmd="dirname ",reportpath_name
report_path=subprocess.check_output('cmd', shell=True)


cmd="basename ",reportpath_name
report_name=subprocess.check_output('cmd', shell=True)

os.chdir(BBWD)
os.mkdir("PostDeploymentReport/Build",buildNumber)
os.chdir("PostDeploymentReport/Build_",buildNumber)


print ("Current working directory is :"+bwd)
with pysftp.Connection('srpgadm@ca33.wellpoint.com') as sftp:

    with sftp.cd(BBWD+"/PostDeployment/Build_"+buildNumber):    
         sftp.cd(report_path)   
         sftp.os.chmod(reportpath_name, 'x')
         sftp.get(report_name)     


#Begin Check for Post Deploy Rule Count Match
os.rmdir(BBWD+'/Deployment_Info.txt')
os.chdir(bwd)
print("Bamboo current working directory is :"+bwd)

cmd="grep doesCountMatch report_rulecountcompare.txt |cut -d '>' -f2|cut -d '<' -f1"
doesCountMatch=subprocess.check_output('cmd', shell=True)
#doesCountMatch
print ("Does Rule Count match in Post Deploy Check:"+doesCountMatch)
if doesCountMatch == "Yes" :
   file1 = open(BBWD+"/Deployment_Info.txt", "a")  # append mode
   file1.write("Deployment is completed in "+ENV+" enviornment. And the rules count match in the post deploy check.\n")
   file1.close()


if "$doesCountMatch" =="Yes" :
   file1 = open(BBWD+"/Deployment_Info.txt", "a")  # append mode
   file1.write("Rule count does not match in "+ENV+" as compared with DEV . For additional information please refer to attached document $report_name.\n")
   file1.close()
   cmd=postDeployNotification_sh+' '+ENV+' '+buildNumber+' '+ENV+'Deployment '+BBWD
   os.system(cmd)
   exit

#End check for Post Deploy Count Match
