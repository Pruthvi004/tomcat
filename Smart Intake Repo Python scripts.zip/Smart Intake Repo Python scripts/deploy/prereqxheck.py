import sys
import os
import subprocess


## Check Version format

ENV=sys.argv[1]
BUILDVERSION=sys.argv[2]
PIPELINE=sys.argv[3]

##Check Version Format

if BUILDVERSION == [0-9]: 
    print("Version suppiled is $BUILDVERSION") 
else:
    print("Please follow the version format (For instance BUILDVERSION=<Build_Number of bamboo>)")
    exit

if PIPELINE == "Major" :
    bamboo_Artifactory="Build_"+BUILDVERSION
    print("Deploying from Major Pipeline Build (bamboo.anthem.com)")
elif PIPELINE == "Minor":
    bamboo_Artifactory="Minor/Build_"+BUILDVERSION
    print("Deploying from Minor Pipeline Build (bamboo.anthem.com)")
elif PIPELINE == "EandB":
    bamboo_Artifactory="EaandB/Build_"+BUILDVERSION
    print("Deploying from EandB Pipeline Build (bamboo.anthem.com)")
elif PIPELINE == "OffCycle":
    bamboo_Artifactory="OffCycle/Build_"+BUILDVERSION
    print("Deploying from OffCycle Pipeline Build (bamboo.anthem.com)")
else:
    print("Please follow the pipeline choice format.Option are Major , Minor, Offcycle or EandB")
    exit 


#remove previous file
os.remove('/local_hone/srcwgsp/DevOps/ArtifactoryInfo/Artifact_'+ENV+'.ArtifactoryInfo')
#set Artifactory Path
cmd='echo "Artifactory = "'+bamboo_Artifactory+' >> /local_hone/srcwgsp/DevOps/ArtifactoryInfo/Artifact_'+ENV+'.info'
os.system(cmd)
