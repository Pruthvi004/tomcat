import os
import sys
import subprocess
from datetime import date

today= date.today()
env=sys.argv[1]
INSKEY=sys.argv[1]
BBWD=sys.argv[1]

utilsfloder=BBWD+"/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/"
agentDevOpsFloderPath="/apps/DevOps"
devDEvOpsFloderPath="/apps/DevOps"

#Spilt the Product version and Product Name from inskey
cmd='echo$I | cut -f2 -d ' ''
product_name=subprocess.check_output('cmd', shell=True)

cmd='echo $INSKEY |cut -f3 -d '''
product_version=subprocess.check_output('cmd', shell=True)

restorepoint_label='Custom RP for import:'+product_name+' at '+today

print ("Product name is :"+product_name)
print ("Product version is :"+product_version)
print ("Restore point label is :"+restorepoint_label)

#Update the restore point label
cmd='sed -i "s/(manageRestorePoints\.restorePointLabel=\).*\$\1'+restorepoint_label+'/ $utilsfloder/'+env+'_prpcServiceUtils.properties'
os.system(cmd)

cmd='grep ^manageRestorePoints.restorePointLabel '+utilsfloder+'/'+env+'_prpcServiceUtils.properties |cut -d =-f2'
updaterestorepoint_label=subprocess.check_output('cmd', shell=True)

print ("Updated Restore Point Label is : "+updaterestorepoint_label)

#set the manageRestorePoints action "Create"

restore_action="create"
cmd ="sed -i -e '/manageRestorepoints.action=/ s|=.*|="+restore_action+" '|' $utilsfloder/"+env+"_prpcServiceUtils.properties"
os.system(cmd)

cmd='grep ^manageRestorePoints.action '+utilsfloder+'/'+env+'_prpcServiceUtils.properties |cut -d =-f2'
updatedrestorepoint_action=subprocess.check_output('cmd', shell=True)

print ("Updated Restore actionis "+updatedrestorepoint_action)

#Run commamd manageRestorePoints to create restore point
os.chdir(utilsfloder)
cmd=utilsfloder+"/"+env+"_prpcServiceUtis.sh manageRestorePints"
os.system(cmd)