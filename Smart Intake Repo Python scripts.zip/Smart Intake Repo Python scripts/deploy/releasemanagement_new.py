from distutils import cmd
import os
import sys
import subprocess
import pysftp
import shutil

#Release Notes Creation
en=sys.argv[1]
#en=${bamboo.ENV}
build=sys.argv[2]
#build=${bamboo.buildNumber}
pr=sys.argv[3]
BBWD=sys.argv[4]
app=sys.argv[5]
pwd=os.getcwd()

agentDevOpsFloderPath='/apps/Devops'
devDevOpsFloderPath='/apps/DevOps'

featureFile=agentDevOpsFloderPath+'/Request/'+app+'FeatureIDList_$en.xml'
rmfile= BBWD+'/Request/RMRequestData/xml'

cmd='cat '+featureFile
update= subprocess.check_output('cmd', shell=True)

print(update)
#sed -i -e "s|<RMTableInput>|<RMTableInput>$update|g" $rmfile
os.chmod(agentDevOpsFloderPath+'/Request' ,0o777)
os.chmod(rmfile , 0o777)
cmd='sed -i "<RMTableInput>/a $update "'+rmfile
os.system(cmd)

os.chmod(agentDevOpsFloderPath+'/Request' ,0o777)
cmd='cat '+rmfile
os.system(cmd)

cmd='sed -i -e "s|<EnvName>.*</EnvName>|<EnvName>'+en+'</EnvName>|g"'+rmfile
os.system(cmd)
cmd='sed -i -e "s|<BuildNumber>.*</BuildNumber>|<BuildNumber>'+build+'</BuildNumber>|g"'+rmfile
os.system(cmd)
cmd='sed -i -e "s|<ProductForFeatureID>.*</ProductForFeatureID>|<ProductForFeatureID>'+pr+'</ProductForFeatureID>|g"'+rmfile
os.system(cmd)


shutil.copy2(rmfile, os.getcwd() )
cmd='cat '+rmfile
os.system(cmd)

cmd='curl --header "Content-Type: text/xml;charset=utf-8" --cacert /apps/tomcat7/tomcat-client.jks --insecure --data @RMRequestData.xml va33.wellpoint.com > report_RMRequestData_$en.txt'
os.system(cmd)

cmd='cat report_RMRequestData_'+en+'.txt'
os.system(cmd)


cmd='cat report_RMRequestData_'+en+'.txt|grep RMTableUpdateStatus|cut -d: -f1|cut -d ">" -f2|xargs'
result=subprocess.check_output('cmd', shell=True)


print("Result from ReleaseManagement api call is :)"+result)

if result != "Success":
    print("ReleaseManagement API call failed.")
    exit

reportpath_name=devDevOpsFloderPath+'/Reports/ReleaseNotes_'+en+'.xls'

print ("Report & its path: "+reportpath_name)

cmd="dirname ",reportpath_name
report_path=subprocess.check_output('cmd', shell=True)


cmd="basename ",reportpath_name
report_name=subprocess.check_output('cmd', shell=True)


print("Report path: "+report_path)
print("Report name: "+report_name)


os.chdir(BBWD)
os.mkdir('ReleaseNotesReport/Build_'+build)
os.chdir(BBWD+'/ReleaseNotesReport/Build_'+build)

# make sure you install pysftp module
with pysftp.Connection('srcwgpg@va33.wellpoint.com') as sftp:

    with sftp.cd(report_path):           
        sftp.get('ReleaseNotes_'+en+'.xls')   



os.remove(featureFile)
