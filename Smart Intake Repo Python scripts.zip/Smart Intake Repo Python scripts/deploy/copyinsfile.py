import os
import sys
import shutil

buildNumber=sys.argv[1]
BUILDKEY=sys.argv[2]
bwd=os.getcwd

print ("Copying the product ins key to the present working directory")
shutil.copy2("/apps/DevOps/Products/Build_"+buildNumber+"/product_ins_key.txt", bwd+"/")

