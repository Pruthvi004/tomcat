from distutils import cmd
import os
import sys
import subprocess
import pysftp
import shutil


en=sys.argv[1]
build=sys.argv[2]
pr=sys.argv[3]
ExportProductRequestData_xml='ExportProductRequestData_'+en+'.xml'
pwd=os.getcwd

rmfile=pwd+'/'+build+'/Request/RMRequestData_$en.xml'
basermname=pwd+'/'+build+'/Request/RMRequestData.xml'

# make sure you install pysftp module
with pysftp.Connection('srcwgpg@va33.wellpoint.com') as sftp:

    with sftp.cd('/apps/DevOps/Request/'):           
        sftp.get('FeatureIDList.xml')   

cmd='sed -i -e "s|<EnvName>.*</EnvName>|<EnvName>'+en+'</EnvName>|g"'+rmfile
os.system(cmd)
cmd='sed -i -e "sed -i -e "s|<BuildName>.*</BuildName>|<BuildName>'+build+'</BuildName>|g"'+rmfile
os.system(cmd)
cmd='sed -i -e "s/<ProductFeatureID>.*</ProductFeatureID>|<ProductInsKey>'+pr+'</ProductInsKey>|g"'+rmfile
os.system(cmd)



cmd='cat '+rmfile
os.system(cmd)
shutil.copy2(rmfile, os.getcwd() )
cmd='cat '+rmfile
os.system(cmd)

cmd='curl --header "Content-Type: text/xml;charset=utf-8" --cacert /apps/tomcat7/tomcat-client.jks --insecure --data @RMRequestData_'+en+'.xml www.wellpoint.com > report_RMRequestData_'+en+'.txt'
os.system(cmd)

cmd='cat report_RMRequestData_'+en+'.txt'
os.system(cmd)

cmd='cat report_RMRequestData_'+en+'.txt|grep RMTableUpdateStatus |cut -d: -f1|cut -d">" -f2|xargs'
results=subprocess.check_output('cmd', shell=True)

print("Result from ReleaseManagement api call is :"+results)

if results != "Success" : 
    print ("ReleaseManagement api call failed")
    exit

reportpath_name='/local_home/srcwgspg/DevOps/Report/'+build+'/ReleaseNotes_$en.xls'

print("Report & its path:"+reportpath_name)

cmd="dirname ",reportpath_name
report_path=subprocess.check_output('cmd', shell=True)


cmd="basename ",reportpath_name
report_name=subprocess.check_output('cmd', shell=True)

os.system('ReleaseNotesReport/Build_'+build)

# make sure you install pysftp module
with pysftp.Connection('srcwgspg@va33.wellpoint.com') as sftp:

    with sftp.cd('/apps/DevOps/Reports/'):           
        sftp.get('ReleaseNotes_'+en+'.xls')         


shutil.copy2( basermname , '/apps/DevOps/Request/RMRequestData_'+en+'.xml')

cmd='cat  /apps/DevOps/Request/RMRequestData_'+en+'.xml'
os.system(cmd)

