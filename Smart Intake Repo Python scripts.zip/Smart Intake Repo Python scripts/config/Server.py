import os
import sys
import subprocess

BBWD=sys.argv[1]
PWD=BBWD+"/config"
KEY=sys.argv[3]
WD=BBWD+"/prpcServiceUtils_84/prpcServiceUtils/scripts/prpcServiceUtils"

print ("Starting Decryption Process")

cmd='openssl enc -aes-256-cbc -d -in '+PWD+'/server.dat -out '+PWD+'/server.properties -k '+KEY+'0'
os.system(cmd)

cmd="cat "+PWD+"/server.properties|grep'pega.rest.username' | cut -d '=' -f2"
pegarestusername=subprocess.check_output('cmd', shell=True)

cat="cat "+PWD+"/server.properties|grep 'pega.rest.password' | cut -d '=' -f2"
pegarestpassword=subprocess.check_output('cmd', shell=True)

cmd="cat "+PWD+"/server.properties|grep 'produsername' | cut -d '=' -f2"
produsername= subprocess.check_output('cmd', shell=True)

cmd="cat "+PWD+"/server.properties|grep 'prodpassword' | cut -d '=' -f2"
prodpassword=subprocess.check_output('cmd', shell=True)

cmd="cat "+PWD+"/server.properties|grep 'keyStorePassword' | cut -d '=' -f2"
keyStorePassword=subprocess.check_output('cmd', shell=True)

cmd="cat "+PWD+"/server.properties|grep 'trustStorePassword' | cut -d '=' -f2"
trustStorePassword=subprocess.check_output('cmd', shell=True)


cmd="sed -i -e 's|pega.rest.username=|pega.rest.username='$pegarestusername '|g '"+PWD+"/DEV_prpcServiceUtils.properties "+PWD+"/PERF_prpcServiceUtils.properties "+PWD+"/UAT_prpcServiceUtils.properties "+PWD+"/SIT_prpcServiceUtils.propertiescmd"
os.system(cmd)

cmd="sed -i -e 's|pega.rest.password=|pega.rest.password='$pegarestpassword '|g' "+PWD+"/DEV_prpcServiceUtils.properties "+PWD+"/PERF_prpcServiceUtils.properties $WD/UAT_prpcServiceUtils.properties "+PWD+"/SIT_prpcServiceUtils.properties"
os.system(cmd)

cmd="sed -i -e 's|trustStorePassword=|trustStorePassword='$trustStorePassword '|g' "+PWD+"/DEV_prpcServiceUtils.properties "+PWD+"/PERF_prpcServiceUtils.properties "+PWD+"/UAT_prpcServiceUtils.properties "+PWD+"/SIT_prpcServiceUtils.properties "+PWD+".PROD_prpcServiceUtils.properties"
os.system(cmd)

cmd="sed -i -e 's|keyStorePassword=|keyStorePassword='$keyStorePassword'|g' "+PWD+"/DEV_prpcServiceUtils.properties "+PWD+"/PERF_prpcServiceUtils.properties "+PWD+"/UAT_prpcServiceUtils.properties "+PWD+"/SIT_prpcServiceUtils.properties "+PWD+".PROD_prpcServiceUtils.properties"
os.system(cmd)

cmd="sed -i -e 's|pega.rest.username=|pega.rest.username='$pegarestusername'|g' "+PWD+".PROD_prpcServiceUtils.properties"
os.system(cmd)

cmd="sed -i -e 's|pega.rest.password=|pega.rest.password='$pegarestpassword '|g' "+PWD+".PROD_prpcServiceUtils.properties"
os.system(cmd)