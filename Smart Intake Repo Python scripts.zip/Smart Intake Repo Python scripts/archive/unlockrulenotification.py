import sys
import os
import smtplib, ssl

buildNumber=sys.argv[1]
planName=sys.argv[2]
BBWD=sys.argv[3]

HandleVersion_Info_txt=BBWD+"/report_HandleVersion.txt"
cmd='cat '+HandleVersion_Info_txt+' |grep HandleVersionStatus| cut -d ">" -f2 |cut -d "<" -f1)'
os.system(cmd)

port = 465  # For SSL
smtp_server="<please fill this>"
sender_email="<please fill this>"
receiver_email="<please fill this>"
password=input("Type your password and press enter:")


ATTACH="$BBWD/report_HandleVersion.txt"

message="""
Subject: <please put the subject>

Team,
 Build Plan: {planName}
 Build Number: {buildNumber}
 Failed Reason : {result}

 Please refer to the attached document for UnlockRuleSet API Response

 Thank You for using EagleEye DevOps

 EagleEye Team"""
 
context = ssl.create_default_context()
with smtplib.SMTP(smtp_server, port) as server:
    server.starttls(context=context)
    server.login(sender_email, password)
    server.sendmail(sender_email, receiver_email, message)

