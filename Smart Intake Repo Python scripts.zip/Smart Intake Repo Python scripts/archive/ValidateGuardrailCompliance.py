import os
import sys
import pathlib

#Check for Guardrail Compliance score
print ("########################## start check for Guardrail compliance score")

BBWD=sys.argv[1]

os.mkdir(BBWD+"/PegaHealthCheckReport")
ValidationInfo_txt=BBWD+"/PegaHealthCheckReport/ValidationInfo.txt"

############################check for presence of ValidationInfo.txt file ###############

file = pathlib.Path(ValidationInfo_txt)
if file.exists ():
   print ("Build failed because of following reason:")
   f = open(ValidationInfo_txt, 'r')
   file_contents = f.read()
   print (file_contents)
   f.close()
