import os
import sys
import datetime
import subprocess

ENV=sys.argv[1]
INSKEY=sys.argv[2]
BBWD=sys.argv[3]
utilsfloder=BBWD+"/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/"

DateValue=datetime.datetime.now().strftime("%Y_%m_%d_%H_%M_%S")

#Spilt the Product Version and Product Name for Inskey
X=INSKEY.split()
product_name=print(X[1])
product_version=print(X[2])
archive_name=product_name+"_"+DateValue

print ("Product path is :"+archive_name)
print ("Product name is: "+product_name)
print ("Product Version is:"+product_version)


cmd="sed -i -e '/export.archiveName=/ s|=.* |='$archive_name' | '$utilsfloder/DEV-prpcServiceUtils.properties"
os.system(cmd)

cmd="grep ^export.archivename $utilsfloder/DEV_prpcServiceUtils.properties |cut -d= -f2"
archive_path_new=os.system(cmd)

cmd="sed -i -e '/export.productName=/ s|=.* |='$product_name' | '$utilsfloder/DEV-prpcServiceUtils.properties"
os.system(cmd)

cmd="grep ^export.productName $utilsfloder/DEV_prpcServiceUtils.properties |cut -d= -f2"
product_name_new=os.system(cmd)


cmd="sed -i -e '/export.productName=/ s|=.* |='$product_version' | '$utilsfloder/DEV-prpcServiceUtils.properties"
os.system(cmd)

cmd="grep ^export.productVersion $utilsfloder/DEV_prpcServiceUtils.properties |cut -d= -f2"
product_version_new= os.system(cmd)

print ("Product path is :"+archive_path_new)
print ("Product name is: "+product_name_new)
print ("Product Version is:"+product_version_new)