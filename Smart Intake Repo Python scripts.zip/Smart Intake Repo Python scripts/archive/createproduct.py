import os
from posixpath import basename
import sys
import shutil
import subprocess

BuildNum=sys.argv[1]
ENV=sys.argv[2]
inskey=sys.argv[3]
BBWD=sys.argv[4]

utilsfloder=BBWD+"/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/"
agentDevOpsFloderPath="/app/DevOps"
devDevOpsFloderPath="/app/DevOps"
product_path=BBWD+"/Products"
path=utilsfloder+"/FinalProduct/"

print(inskey)

os.chdir(utilsfloder+"/FinalProduct/")
print(subprocess.check_output(['ls', '-al', path]).decode('utf-8'))
product_name=os.system('basename *.zip')
print ("productname"+product_name)

os.chdir(BBWD)
os.mkdir("Products/Build_"+BuildNum)

##Copy Product in working directory to Define artifact
shutil.copyfile(utilsfloder+"/FinalProduct/"+product_name , product_path+"/Build_"+BuildNum )

product_path_new=product_path+"/Build_"+BuildNum
productpath_name_new=product_path_new+"/"+product_name

#Save Product INS Key into Build <BuildNumber> Directory with  product artifactory
file1 = open(product_path_new+"/product_ins_key.txt", "w")  # write mode
file1.write("inskey= "+inskey+ "\n")
file1.close()
