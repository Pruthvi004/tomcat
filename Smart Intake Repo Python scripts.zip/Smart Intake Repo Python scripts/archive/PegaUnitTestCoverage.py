#Check Pega Unit Test Coverage For Current Build
from distutils import cmd
import os
import sys
import subprocess
import pysftp

buildNumber=sys.argv[1]
BBWD=sys.argv[2]
app=sys.argv[3]
bwd=os.getcwd()

agentDevOpsFloderPath="/app/DevOps"
devDevOpsFloderPath="/app/DevOps"

PegaCoverageRequestData_xml=BBWD+"/Request/"+app+"PegaCoverageRequestData.xml"

cmd="cat ",BBWD,"/config/server.properties |grep pega.rest.username |cut -d '=' -f2)"
pegarestusername = subprocess.check_output('cmd', shell=True)

cmd="cat ",BBWD,"/config/server.properties |grep 'pega.rest.password' |cut -d '=' -f2"
pegarestpassword = subprocess.check_output('cmd', shell=True)


cmd='curl -v --header "Content_type: text/xml:charset=UTF-8" --cacert /apps/tomcat7.tomcat-client.jks --insecure -u "$pegarestusername:$pegarestpassword" --data @',PegaCoverageRequestData_xml,' www.wellpoint.com  > report_pegacoverage.txt'
os.system(cmd)


os.system("cat report_pegacoverage.txt")

cmd='cat report_pegacoverage.txt| grep TestCoverageStatus | cut -d- -f2| cut -d\< -f1'
reportpath_name = subprocess.check_output('cmd', shell=True)


print ("Report & its path: $reportpath_name")
cmd="dirname ",reportpath_name
report_path=subprocess.check_output('cmd', shell=True)


cmd="basename ",reportpath_name
report_name=subprocess.check_output('cmd', shell=True)

##Copy Unit Test Coverage In Coverage in Working directory to Define artifact

os.chdir(BBWD)
os.mkdir("PegaTestCoverageReport/Build_",buildNumber)
os.chdir("PegaTestCoverageReport/Build_",buildNumber)

#sftp srccomp@va12.wellpoint.com <<EOF
# make sure you install pysftp module
with pysftp.Connection('srccompg@va12.wellpoint.com') as sftp:

    with sftp.cd(report_path):           
        sftp.get(report_name)         


