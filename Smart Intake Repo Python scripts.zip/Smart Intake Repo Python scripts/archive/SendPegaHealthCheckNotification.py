
import fileinput
import sys
import os
import subprocess
from pathlib import Path
import email, smtplib, ssl
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

BBWD=sys.argv[1]
buildNum=sys.argv[2]
planName=sys.argv[3]
RELEASE=sys.argv[4]
env=sys.argv[5]

pegahealthcheckdir=BBWD+"/PegaHealthCheckReport"
ValidationInfo_txt=pegahealthcheckdir+"/ValidationInfo.txt"
Info_Product_txt=pegahealthcheckdir+"/GuardrailsOnProductInfo.txt"
Info_txt=pegahealthcheckdir+"/GuardrailsInfo.txt"
PegaUnitInfo_txt=pegahealthcheckdir+"/PegaUnitInfo.txt"
cmd='cat'+ValidationInfo_txt
bodymessage = subprocess.check_output('cmd', shell=True)

print ("Message body is :"+bodymessage)


port = 465  # For SSL
smtp_server="<please fill this>"
sender_email="<please fill this>"
receiver_email="<please fill this>"
password=input("Type your password and press enter:")

subject = "DevOps Health Check Report - PegaKM $env - {RELEASE} Build : {buildNum}"
sender_email = "my@gmail.com"
receiver_email = "your@gmail.com"
password = input("Type your password and press enter:")
body="""
SUBJECT="DevOps Health Check Report - PegaKM $env - {RELEASE} Build : {buildNum}"

Team

Build Plan : {planName}
Build Number: {buildNum}
{bodymessage}

NOTE: Guardrail Compliance Score must be at 90 or above in order to pass PERF enviornment and approved for PROD release.For additional information on Guardrails health please refer to attched documents.

Thanks for Using Eagle Eye Devops

EagleEye Team""" 

# Create a multipart message and set headers
message = MIMEMultipart()
message["From"] = sender_email
message["To"] = receiver_email
message["Subject"] = subject
message["Bcc"] = receiver_email  # Recommended for mass emails

# Add body to email
message.attach(MIMEText(body, "plain"))


path_to_file = ValidationInfo_txt
path = Path(path_to_file)

if path.is_file():
#Find the total no of reports
   os.chdir(pegahealthcheckdir)
   print ("\nCurrent Working Directory")
   os.getcwd
   cmd="find . -type f -name '*.xls*'|wc -1"
   TotalReports=subprocess.check_output('cmd', shell=True)
   print ("\nTotal no of reports="+TotalReports)

#Files name
   print ("/nReports to be sent =")
   cmd="ls -al |grep '.xls'| awk '{print $9}'"
   os.system(cmd)
  

   if TotalReports > 1: 
      cmd="ls-al |grep '.xls' |awk '{print $9)'"
      S=subprocess.check_output('cmd', shell=True)
      list=S.read().splitlines()

      for i in list:
      attlogs+=("-a" "$i")
      
      path_to_file = Info_Product_txt
      path = Path(path_to_file)
      if path.is_file(): 
        attlogs+=("-a" "$Info_Product_txt") 
        print (Info_Product_txt+"exits")
      
      path_to_file = Info_txt
      path = Path(path_to_file)
      if path.is_file(): 
        attlogs+=("-a" "$Info_txt") 
        print (Info_txt+"exits")      


      path_to_file = PegaUnitInfo_txt
      path = Path(path_to_file)
      if path.is_file(): 
        attlogs+=("-a" "$PegaUnitInfo_txt") 
        print (PegaUnitInfo_txt+"exits")   

      filename = "attlogs"  # In same directory as script
      f = fileinput(filename)
      attachment = MIMEText(f.read())
      attachment.add_header('Content-Disposition', 'attachment', filename=filename) 
      message.attach(attachment)
      text = message.as_string()

      # Log in to server using secure context and send email
      context = ssl.create_default_context()
      with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
          server.login(sender_email, password)
          server.sendmail(sender_email, receiver_email, text)
   


   if env != 'DEV':
      text = message.as_string()

      # Log in to server using secure context and send email
      context = ssl.create_default_context()
      with smtplib.SMTP_SSL("smtp.gmail.com", 465, context=context) as server:
          server.login(sender_email, password)
          server.sendmail(sender_email, receiver_email, text)

   
   