import os
import sys
buildNumber=sys.argv[1]
inskey=sys.argv[2]
app=sys.argv[3]

agentDevOpsFloderPath= "/app/agentDevOpsFloderPath"
devDevOpsFloderPath= "/app/devDevOpsFloderPath"

#Removing previous file 
os.mkdir(agentDevOpsFloderPath+"/ArtifactoryInfo")
os.remove(agentDevOpsFloderPath+"/ArtifactoryInfo/"+app+"KMBuild.ArtifactoryInfo")

#Sorting new build info
file1 = open(agentDevOpsFloderPath+"/ArtifactoryInfo/"+app+"KMBuild.info.txt", "a")  # append mode
file1.write("BuildNumber ="+buildNumber+ "\n")
file1.close()
