import sys
import shutil
#Removes the jar file after it has been sent to artifactory
buildNum=sys.argv[1]
BBWD=sys.argv[2]

agentDevOpsFloderPath="/apps/DevOps"
devDevOpsFloderPath="/apps/DevOps"



shutil.rmtree('/path/to/your/dir/')
shutil.rmtree(BBWD+'/prpcServiceUtils_84/prpcServiceUtils/scripts/utils/FinalProduct/*')
shutil.rmtree(agentDevOpsFloderPath+'/prpcServiceUtils_84/scripts/utils/FinalProduct/*')
shutil.rmtree(BBWD+'/Products/*')
shutil.rmtree(agentDevOpsFloderPath+'/Products/*')
